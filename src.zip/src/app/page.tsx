import AgentCreationInterface from '@/components/AgentCreationInterface';
import AgentManagementInterface from '@/components/AgentManagementInterface';
import OverWatchPanel from '@/components/OverWatchPanel';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Home() {
  try {
    return (
      <div className="container mx-auto py-10">
        <Tabs defaultValue="create" className="w-[100%]">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="create">Create Agent</TabsTrigger>
            <TabsTrigger value="manage">Manage Agents</TabsTrigger>
            <TabsTrigger value="overwatch">OverWatch Panel</TabsTrigger>
          </TabsList>
          <TabsContent value="create" className="mt-6">
            <AgentCreationInterface />
          </TabsContent>
          <TabsContent value="manage" className="mt-6">
            <AgentManagementInterface />
          </TabsContent>
          <TabsContent value="overwatch" className="mt-6">
            <OverWatchPanel />
          </TabsContent>
        </Tabs>
      </div>
    );
  } catch (error: any) {
    console.error('Error in Home page:', error);
    return (
      <div className="container mx-auto py-10">
        <h2>Error</h2>
        <p>An error occurred while rendering the home page.</p>
        <p>Please try again later.</p>
        <p>Error details: {error.message}</p>
      </div>
    );
  }
}
