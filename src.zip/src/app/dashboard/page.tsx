'use client';

import React, {useState, useEffect} from 'react';
import {Shell} from '@/components/Shell';
import {Card, CardContent, CardDescription, CardHeader, CardTitle} from '@/components/ui/card';
import {useRouter} from 'next/navigation';
import {Activity} from 'lucide-react';
import {DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger} from "@/components/ui/dropdown-menu";
import {Button} from "@/components/ui/button";
import {Icons} from "@/components/icons";
import {Progress} from "@/components/ui/progress"; // Import Progress component
import {cn} from "@/lib/utils";
import {useToast} from "@/hooks/use-toast";

const Dashboard = () => {
  try {
    const router = useRouter();
    const [agents, setAgents] = useState<any[]>([]);
    const {toast} = useToast();

    const loadAgents = () => {
      const storedAgents = localStorage.getItem('agents');
      if (storedAgents) {
        setAgents(JSON.parse(storedAgents));
      }
    };

    useEffect(() => {
      loadAgents();
      const intervalId = setInterval(loadAgents, 5000);

      return () => clearInterval(intervalId);
    }, []);

    useEffect(() => {
      localStorage.setItem('agents', JSON.stringify(agents));
    }, [agents]);

    const toggleAgentStatus = (agentId: string) => {
      setAgents(prevAgents =>
        prevAgents.map(agent =>
          agent.id === agentId ? {...agent, status: agent.status === 'active' ? 'inactive' : 'active'} : agent
        )
      );
    };

    const deleteAgent = (agentId: string) => {
      setAgents(prevAgents => prevAgents.filter(agent => agent.id !== agentId));
      localStorage.setItem('agents', JSON.stringify(agents.filter(agent => agent.id !== agentId)))
      toast({
        title: "Agent Deleted",
        description: "Your agent has been successfully deleted.",
      })
    };

    const pauseAgent = (agentId: string) => {
      setAgents(prevAgents =>
        prevAgents.map(agent => (agent.id === agentId ? {...agent, status: 'inactive'} : agent))
      );
      toast({
        title: "Agent Paused",
        description: "Your agent has been successfully paused.",
      })
    };

    const archiveAgent = (agentId: string) => {
      // Implement archive logic here, e.g., move to a separate archive array
      setAgents(prevAgents => prevAgents.filter(agent => agent.id !== agentId));
      localStorage.setItem('agents', JSON.stringify(agents.filter(agent => agent.id !== agentId)))

      toast({
        title: "Agent Archived",
        description: "Your agent has been successfully archived.",
      })
    };

    const getStatusColor = (status: string) => {
      switch (status) {
        case 'active':
          return 'text-green-500';
        case 'inactive':
          return 'text-gray-500';
        case 'error':
          return 'text-red-500';
        default:
          return 'text-gray-500';
      }
    };

    return (
      <Shell>
        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Live Tile Interactive Dashboard</CardTitle>
              <CardDescription>Agent Status and Control.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {agents.map(agent => (
                  <div
                    key={agent.id}
                    className={`rounded-lg p-4 hover:glow ${
                      agent.status === 'active' ? 'bg-green-500' : 'bg-secondary'
                    }`}
                  >
                    <button
                      onClick={() => toggleAgentStatus(agent.id)}
                      className="w-full text-left"
                    >
                      <div className="flex items-center space-x-2">
                        <Activity className="text-lg" />
                        <h3 className="text-lg font-semibold">Agent: {agent.name}</h3>
                      </div>
                      <p>Status: <span className={getStatusColor(agent.status)}>{agent.status === 'active' ? 'Active' : 'Inactive'}</span></p>
                      <p>Task Progress: {agent.taskProgress}%</p>
                      <p>Resource Usage: CPU: {agent.resourceUsage}%</p>
                      <p className="mt-2">Activity:</p>
                      <Progress value={agent.activityLevel} className="bg-blue-500"/>
                      <p>Data Load:</p>
                      <Progress value={agent.dataLoad} className="bg-purple-500"/>
                      <p>Neural Load:</p>
                      <Progress value={agent.neuralLoad} className="bg-orange-500"/>
                    </button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <Icons.chevronDown className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => deleteAgent(agent.id)}>
                          Delete
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => pauseAgent(agent.id)}>
                          Pause
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => archiveAgent(agent.id)}>
                          Archive
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </Shell>
    );
  } catch (error: any) {
    console.error('Error in Dashboard:', error);
    return (
      <Shell>
        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Error</CardTitle>
              <CardDescription>An error occurred while rendering the dashboard.</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Please try again later.</p>
              <p>Error details: {error.message}</p>
            </CardContent>
          </Card>
        </div>
      </Shell>
    );
  }
};

export default Dashboard;
