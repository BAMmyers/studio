'use server';

/**
 * @fileOverview Analyzes errors during prompt processing and suggests solutions.
 *
 * - analyzePromptError - A function that analyzes prompt errors and suggests solutions.
 * - PromptErrorAnalysisInput - The input type for the analyzePromptError function.
 * - PromptErrorAnalysisOutput - The return type for the analyzePromptError function.
 */

import {ai} from '@/ai/ai-instance';
import {z} from 'genkit';

const PromptErrorAnalysisInputSchema = z.object({
  prompt: z.string().describe('The user prompt that caused the error.'),
  errorDetails: z.string().describe('Detailed error message encountered during prompt processing.'),
});
export type PromptErrorAnalysisInput = z.infer<typeof PromptErrorAnalysisInputSchema>;

const PromptErrorAnalysisOutputSchema = z.object({
  analysis: z.string().describe('Analysis of the error, including potential causes.'),
  suggestedSolutions: z.array(z.string()).describe('Array of suggested solutions or improvements to the prompt.'),
});
export type PromptErrorAnalysisOutput = z.infer<typeof PromptErrorAnalysisOutputSchema>;

export async function analyzePromptError(input: PromptErrorAnalysisInput): Promise<PromptErrorAnalysisOutput> {
  try {
    return await analyzePromptErrorFlow(input);
  } catch (error: any) {
    console.error('Error in analyzePromptError:', error);
    throw new Error(`Failed to analyze prompt error: ${error.message}`);
  }
}

const prompt = ai.definePrompt({
  name: 'promptErrorAnalysisPrompt',
  input: {
    schema: z.object({
      prompt: z.string().describe('The user prompt that caused the error.'),
      errorDetails: z.string().describe('Detailed error message encountered during prompt processing.'),
    }),
  },
  output: {
    schema: z.object({
      analysis: z.string().describe('Analysis of the error, including potential causes.'),
      suggestedSolutions: z.array(z.string()).describe('Array of suggested solutions or improvements to the prompt.'),
    }),
  },
  prompt: `You are an AI assistant specialized in analyzing errors that occur during prompt processing and suggesting solutions.

You will receive the user's original prompt and the detailed error message. Your task is to analyze the error, identify the potential causes, and suggest specific solutions or improvements to the prompt.

Original Prompt: {{{prompt}}}
Error Details: {{{errorDetails}}}

Provide a detailed analysis of the error and a list of suggested solutions.
`,
});

const analyzePromptErrorFlow = ai.defineFlow<
  typeof PromptErrorAnalysisInputSchema,
  typeof PromptErrorAnalysisOutputSchema
>({
  name: 'analyzePromptErrorFlow',
  inputSchema: PromptErrorAnalysisInputSchema,
  outputSchema: PromptErrorAnalysisOutputSchema,
},
async input => {
  try {
    const {output} = await prompt(input);
    return output!;
  } catch (error: any) {
    console.error('Error in analyzePromptErrorFlow:', error);
    throw new Error(`Prompt analysis failed: ${error.message}`);
  }
});
