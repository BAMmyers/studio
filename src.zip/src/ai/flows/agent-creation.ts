'use server';
/**
 * @fileOverview Creates a new AI agent based on a text prompt.
 *
 * - createAgent - A function that handles the agent creation process.
 * - CreateAgentInput - The input type for the createAgent function.
 * - CreateAgentOutput - The return type for the createAgent function.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *  Development Credits
 *   Developer: Brandon A Myers
 *   Organization: AgentricAI
 *   Email: agentricaiuiux@gmail.com
 *   GitHub Repository: https://github.com/BAMmyers/AgentricAi.git
 *
 */

import {ai} from '@/ai/ai-instance';
import {z} from 'genkit';

/**
 * @description Input schema for the createAgent function.
 */
const CreateAgentInputSchema = z.object({
  prompt: z.string().describe('The text prompt describing the AI agent to create.'),
  agentRole: z.string().describe('The role of the AI agent (e.g., Network Operations Manager, Vulnerability Scanner).'),
  agentResponsibilities: z.string().describe('A detailed description of the agent\'s responsibilities.'),
  reportingTo: z.string().optional().describe('The name of the management team AI this agent reports to (if any).'),
});
export type CreateAgentInput = z.infer<typeof CreateAgentInputSchema>;

/**
 * @description Output schema for the createAgent function.
 */
const CreateAgentOutputSchema = z.object({
  agentInstructions: z
    .string()
    .describe('Detailed instructions for creating the AI agent based on the prompt.'),
  agentType: z.string().describe('The type of AI agent to create (e.g., single-task, double-task).'),
  requiredSkills: z.array(z.string()).describe('The skill or skills needed for the Agent to complete its tasks.'),
});
export type CreateAgentOutput = z.infer<typeof CreateAgentOutputSchema>;

export async function createAgent(input: CreateAgentInput): Promise<CreateAgentOutput> {
  try {
    return await createAgentFlow(input);
  } catch (error: any) {
    console.error('Error in createAgent:', error);
    throw new Error(`Failed to create agent: ${error.message}`);
  }
}

/**
 * @description Prompt that defines agent ceration.
 */
const prompt = ai.definePrompt({
  name: 'createAgentPrompt',
  input: {
    schema: z.object({
      prompt: z.string().describe('The text prompt describing the AI agent to create.'),
      agentRole: z.string().describe('The role of the AI agent (e.g., Network Operations Manager, Vulnerability Scanner).'),
      agentResponsibilities: z.string().describe('A detailed description of the agent\'s responsibilities.'),
      reportingTo: z.string().optional().describe('The name of the management team AI this agent reports to (if any).'),
    }),
  },
  output: {
    schema: z.object({
      agentInstructions: z
        .string()
        .describe('Detailed instructions for creating the AI agent based on the prompt.'),
      agentType: z.string().describe('The type of AI agent to create (e.g., single-task, double-task).'),
      requiredSkills: z.array(z.string()).describe('The skill or skills needed for the Agent to complete its tasks.'),
    }),
  },
  prompt: `You are Dave, an AI assistant that translates user prompts into instructions for creating AI agents.

  Based on the following prompt, generate detailed instructions for creating the AI agent. Determine the type of agent (single-task, double-task), and list any required skills for the agent.

  Here are details about the agent to create:

  Role: {{{agentRole}}}
  Responsibilities: {{{agentResponsibilities}}}
  Reporting To: {{{reportingTo}}}

  Prompt: {{{prompt}}}

  Instructions:`,
});

const createAgentFlow = ai.defineFlow<
  typeof CreateAgentInputSchema,
  typeof CreateAgentOutputSchema
>(
  {
    name: 'createAgentFlow',
    inputSchema: CreateAgentInputSchema,
    outputSchema: CreateAgentOutputSchema,
  },
  async input => {
    try {
      const {output} = await prompt(input);
      return output!;
    } catch (error: any) {
      console.error('Error in createAgentFlow:', error);
      throw new Error(`Prompt processing failed: ${error.message}`);
    }
  }
);
