'use server';
/**
 * @fileOverview A general processes AI agent for handling general functionality and "on click" operations.
 *
 * - handleGeneralProcess - A function that handles the general process.
 * - GeneralProcessInput - The input type for the handleGeneralProcess function.
 * - GeneralProcessOutput - The return type for the handleGeneralProcess function.
 */

import {ai} from '@/ai/ai-instance';
import {z} from 'genkit';

const GeneralProcessInputSchema = z.object({
  task: z.string().describe('The task to be performed (e.g., navigation, button click).'),
  details: z.string().optional().describe('Additional details about the task.'),
  elementId: z.string().optional().describe('The ID of the element related to the task.'),
});
export type GeneralProcessInput = z.infer<typeof GeneralProcessInputSchema>;

const GeneralProcessOutputSchema = z.object({
  success: z.boolean().describe('Whether the process was handled successfully.'),
  message: z.string().optional().describe('A message describing the outcome of the process.'),
  nextAction: z.string().optional().describe('The next action to take.'),
});
export type GeneralProcessOutput = z.infer<typeof GeneralProcessOutputSchema>;

export async function handleGeneralProcess(input: GeneralProcessInput): Promise<GeneralProcessOutput> {
  try {
    return await generalProcessFlow(input);
  } catch (error: any) {
    console.error('Error in handleGeneralProcess:', error);
    return {
      success: false,
      message: `Failed to handle general process: ${error.message}`,
    };
  }
}

const prompt = ai.definePrompt({
  name: 'generalProcessPrompt',
  tools: ['getAllAgents', 'getAgentDetails'],
  input: {
    schema: z.object({
      task: z.string().describe('The task to be performed (e.g., navigation, button click).'),
      details: z.string().optional().describe('Additional details about the task.'),
       elementId: z.string().optional().describe('The ID of the element related to the task.'),
    }),
  },
  output: {
    schema: z.object({
      success: z.boolean().describe('Whether the process was handled successfully.'),
      message: z.string().optional().describe('A message describing the outcome of the process.'),
      nextAction: z.string().optional().describe('The next action to take.'),
    }),
  },
  prompt: `You are an AI assistant tasked with ensuring smooth user experience by handling general processes and "on click" operations.

You have access to the following tools:
- getAllAgents: Retrieves a list of all AI agents with their details.
- getAgentDetails: Retrieves details for a specific AI agent given its ID.

You will receive a task and optional details. Your job is to determine if the task can be successfully handled and, if so, provide a message indicating the outcome and any next steps.

Task: {{{task}}}
Details: {{{details}}}
Element ID: {{{elementId}}}

Consider the current list of agents and their status when determining the next action.
{{#if (eq task "navigation")}}
  Consider the user's destination and the current state of the agents when suggesting the next action. Use getAllAgents to see the current state.
{{/if}}
{{#if elementId}}
  Use getAgentDetails to get more information about the element with ID: {{{elementId}}}.
{{/if}}

Respond with whether the task was successful, a message, and the next action to take.`,
});

const generalProcessFlow = ai.defineFlow<
  typeof GeneralProcessInputSchema,
  typeof GeneralProcessOutputSchema
>(
  {
    name: 'generalProcessFlow',
    inputSchema: GeneralProcessInputSchema,
    outputSchema: GeneralProcessOutputSchema,
  },
  async input => {
    try {
      const {output} = await prompt(input);
      return output!;
    } catch (error: any) {
      console.error('Error in generalProcessFlow:', error);
      return {
        success: false,
        message: `Prompt processing failed: ${error.message}`,
      };
    }
  }
);
