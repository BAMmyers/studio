import {genkit} from 'genkit';
import {googleAI} from '@genkit-ai/googleai';
import {z} from 'zod';

// Declare ai first
export const ai = genkit({
  promptDir: './prompts',
  plugins: [
    googleAI({
      apiKey: process.env.GOOGLE_GENAI_API_KEY,
    }),
  ],
  model: 'googleai/gemini-2.0-flash',
  tools: [], // Initialize tools to an empty array to avoid errors
});

// Define the schema for agent details
const AgentDetailsSchema = z.object({
  id: z.string(),
  name: z.string(),
  status: z.string(),
  taskProgress: z.number(),
  resourceUsage: z.number(),
  activityLevel: z.number(),
  dataLoad: z.number(),
  neuralLoad: z.number(),
});

// Define a type for agent details
export type AgentDetails = z.infer<typeof AgentDetailsSchema>;

// Define the getAllAgents tool
const getAllAgents = ai.defineTool({
  name: 'getAllAgents',
  description: 'Retrieves a list of all AI agents with their details.',
  outputSchema: z.array(AgentDetailsSchema),
}, async () => {
  // Access localStorage within the tool's execution context
  if (typeof localStorage !== 'undefined') {
    const agentsString = localStorage.getItem('agents');
    if (agentsString) {
      try {
        const agents = JSON.parse(agentsString);
        return agents;
      } catch (error) {
        console.error('Error parsing agents from localStorage:', error);
        return [];
      }
    }
  }
  return [];
});

// Define the getAgentDetails tool
const getAgentDetails = ai.defineTool({
  name: 'getAgentDetails',
  description: 'Retrieves details for a specific AI agent given its ID.',
  inputSchema: z.object({
    agentId: z.string().describe('The ID of the AI agent to retrieve.'),
  }),
  outputSchema: z.optional(AgentDetailsSchema),
}, async (input) => {
  // Access localStorage within the tool's execution context
  if (typeof localStorage !== 'undefined') {
    const agentsString = localStorage.getItem('agents');
    if (agentsString) {
      try {
        const agents: AgentDetails[] = JSON.parse(agentsString);
        const agent = agents.find(agent => agent.id === input.agentId);
        return agent || null;
      } catch (error) {
        console.error('Error parsing agents from localStorage:', error);
        return null;
      }
    }
  }
  return null;
});

if (!ai.tools) {
  ai.tools = [];
}

ai.tools.push(getAllAgents, getAgentDetails);
