
import * as React from 'react';
import { cn } from '@/lib/utils';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { ArrowLeft, ArrowRight } from 'lucide-react';

export function Shell({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  const router = useRouter();

  return (
    <div className={cn('container relative mx-auto space-y-8 pb-20', className)}>
      <div className="flex justify-between items-center mb-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => router.back()}
          aria-label="Go back"
        >
          <ArrowLeft className="h-4 w-4 text-gray-400" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => router.forward()}
          aria-label="Go forward"
        >
          <ArrowRight className="h-4 w-4 text-gray-400" />
        </Button>
      </div>
      {children}
    </div>
  );
}


