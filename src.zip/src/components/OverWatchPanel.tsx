'use client';

import React, { useState, useEffect } from 'react';
import {Card, CardContent, CardHeader, CardTitle} from '@/components/ui/card';
import {Button} from '@/components/ui/button';
import {Shell} from "@/components/Shell";
import {Separator} from "@/components/ui/separator";
import { useRouter } from 'next/navigation';
import { Switch } from "@/components/ui/switch";

const OverWatchPanel = () => {
  const router = useRouter();
    const [isChatEnabled, setIsChatEnabled] = useState(() => {
    // Get the initial value from localStorage
    const storedValue = localStorage.getItem('isChatEnabled');
    return storedValue === 'true' || false; // Convert string to boolean
  });

  useEffect(() => {
    // You can add logic here to persist the chat state if needed
    // For example, store the state in localStorage
     localStorage.setItem('isChatEnabled', String(isChatEnabled));
  }, [isChatEnabled]);

  const handleDeployClick = () => {
    router.push('/dashboard');
  };

  return (
    <Shell>
      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>OverWatch Panel</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4">
            <Button onClick={handleDeployClick}>Deploy (Activate)</Button>
            <Button variant="secondary">Test and Train (Benchmarks and Dataset Upload)</Button>
            <Button variant="secondary">Log (Terminal)</Button>
            <Button variant="secondary">Save as (File Explorer)</Button>
            <Separator />
            <Button variant="destructive">SAFTY KILL SWITCH (Auto Pause All Operations and Sandbox)</Button>

            <div className="flex items-center space-x-2">
              <label htmlFor="chat-toggle">Enable Chat:</label>
              <Switch
                id="chat-toggle"
                checked={isChatEnabled}
                onCheckedChange={setIsChatEnabled}
                className="ml-2"
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </Shell>
  );
};

export default OverWatchPanel;
