'use client';

import React from 'react';
import {Card, CardContent, CardDescription, CardHeader, CardTitle} from '@/components/ui/card';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {ScrollArea} from "@/components/ui/scroll-area";
import {Separator} from "@/components/ui/separator";
import {DropdownMenu, DropdownMenuCheckboxItem, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger} from "@/components/ui/dropdown-menu";
import {Shell} from "@/components/Shell";
import { Icons } from './icons';

interface Agent {
  id: string;
  name: string;
  type: string;
  status: 'active' | 'inactive' | 'error';
}

const DUMMY_AGENTS: Agent[] = [
  { id: '1', name: 'Agent Alpha', type: 'Single-Task', status: 'active' },
  { id: '2', name: 'Agent Beta', type: 'Double-Task', status: 'inactive' },
  { id: '3', name: 'Agent Gamma', type: 'Single-Task', status: 'error' },
];

const AgentManagementInterface = () => {
  try {
    return (
      <Shell>
        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Agent Management Interface</CardTitle>
              <CardDescription>
                Manage and monitor your AI agents in real-time.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <Input type="text" placeholder="Search agents..." className="w-full md:w-auto"/>
                <Button>Add New Agent</Button>
              </div>
              <Separator className="my-4"/>
              <ScrollArea>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {DUMMY_AGENTS.map((agent) => (
                      <TableRow key={agent.id}>
                        <TableCell>{agent.name}</TableCell>
                        <TableCell>{agent.type}</TableCell>
                        <TableCell>{agent.status}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <Icons.chevronDown className="h-4 w-4"/>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>Edit</DropdownMenuItem>
                              <DropdownMenuItem>View Logs</DropdownMenuItem>
                              <DropdownMenuSeparator/>
                              <DropdownMenuItem>Deactivate</DropdownMenuItem>
                              <DropdownMenuItem>Delete</DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </Shell>
      );
    } catch (error: any) {
      console.error('Error in AgentManagementInterface:', error);
      return (
        <Shell>
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Error</CardTitle>
                <CardDescription>An error occurred while rendering the agent management interface.</CardDescription>
              </CardHeader>
              <CardContent>
                <p>Please try again later.</p>
                <p>Error details: {error.message}</p>
              </CardContent>
            </Card>
          </div>
        </Shell>
      );
    }
};

export default AgentManagementInterface;
