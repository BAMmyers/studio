'use client';

import React, {useState, useEffect, useRef} from 'react';
import {Avatar, AvatarFallback, AvatarImage} from "@/components/ui/avatar";
import {Button} from "@/components/ui/button";
import {Textarea} from "@/components/ui/textarea";
import {cn} from "@/lib/utils";
import {Switch} from "@/components/ui/switch";
import 'dragula/dist/dragula.css'; // Import dragula CSS

interface ChatMessage {
  sender: 'user' | 'dave';
  text: string;
}

const ChatWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const widgetRef = useRef<HTMLDivElement>(null);
  const [isChatEnabled, setIsChatEnabled] = useState(true);
  const [position, setPosition] = useState({x: 'auto', y: 'auto'}); // Initial position
    const [isDragging, setIsDragging] = useState(false); // Track dragging state

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setIsChatEnabled(localStorage.getItem('isChatEnabled') === 'true' || false);
    }
  }, []);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('isChatEnabled', String(isChatEnabled));
    }
  }, [isChatEnabled]);

  useEffect(() => {
    // Use dynamic import to load dragula only on the client-side
    if (typeof window !== 'undefined') {
      import('dragula')
        .then(({default: dragula}) => {
          if (widgetRef.current) {
            dragula([widgetRef.current])
              .on('drag', () => setIsDragging(true)) // Set dragging state
              .on('dragend', () => setIsDragging(false)); // Clear dragging state
          }
        })
        .catch(error => console.error("Failed to load dragula", error));
    }
  }, []);


  // Function to add a new message to the chat
  const sendMessage = () => {
    if (newMessage.trim() !== '') {
      setMessages([...messages, {sender: 'user', text: newMessage}]);
      // Simulate Dave's reply after a short delay
      setTimeout(() => {
        setMessages(prevMessages => [...prevMessages, {
          sender: 'dave',
          text: `Dave: Thanks for your message: "${newMessage}". I'm processing it now.`
        }]);
      }, 500);
      setNewMessage(''); // Clear the input
    }
  };

  // Scroll to bottom on new messages
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  const handleToggle = () => {
    setIsOpen(!isOpen);
  };

  return (
    isChatEnabled && (
      <div
        className={cn(
          "fixed bottom-6 right-6 z-[9999] h-[400px] w-96 bg-secondary p-4 rounded-l-lg shadow-xl transition-transform duration-300",
          isOpen ? "translate-x-0" : "translate-x-full"
        )}
        ref={widgetRef}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Avatar>
              <AvatarImage src="https://picsum.photos/50/50" alt="Dave"/>
              <AvatarFallback>D</AvatarFallback>
            </Avatar>
            <span className="text-sm font-semibold">Dave (AI Assistant)</span>
          </div>
          <Button onClick={handleToggle} disabled={isDragging}>
            {isOpen ? 'Close Chat' : 'Open Chat'}
          </Button>
        </div>

        <div
          className="bg-background p-4 h-[220px] overflow-y-auto"
          ref={chatContainerRef}
        >
          {messages.map((message, index) => (
            <div
              key={index}
              className={`mb-2 p-2 rounded-md ${message.sender === 'user' ? 'bg-accent text-accent-foreground ml-auto w-fit' : 'bg-muted text-foreground mr-auto w-fit'}`}
            >
              {message.text}
            </div>
          ))}
        </div>

        <div className="bg-secondary p-4 flex space-x-2">
          <Textarea
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type your message..."
            className="flex-grow rounded-md"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
              }
            }}
          />
          <Button onClick={sendMessage} disabled={isDragging}>Send</Button>
        </div>
      </div>
    )
  );
};

export default ChatWidget;
