'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { analyzePromptError, PromptErrorAnalysisOutput } from "@/ai/flows/prompt-error-analysis";
import { createAgent, CreateAgentOutput } from "@/ai/flows/agent-creation";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Icons } from './icons';
import { Shell } from './Shell';
import { useRouter } from 'next/navigation';
import { useToast } from "@/hooks/use-toast"

const AgentCreationInterface = () => {
  try {
    const [prompt, setPrompt] = useState('');
    const [agentRole, setAgentRole] = useState('');
    const [agentResponsibilities, setAgentResponsibilities] = useState('');
    const [reportingTo, setReportingTo] = useState('');
    const [agentInstructions, setAgentInstructions] = useState<CreateAgentOutput | null>(null);
    const [errorAnalysis, setErrorAnalysis] = useState<PromptErrorAnalysisOutput | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const router = useRouter();
    const { toast } = useToast()

    const handlePromptChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      setPrompt(e.target.value);
    };

    const handleAgentRoleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      setAgentRole(e.target.value);
    };

    const handleAgentResponsibilitiesChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      setAgentResponsibilities(e.target.value);
    };

    const handleReportingToChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      setReportingTo(e.target.value);
    };


    const handleCreateAgent = async () => {
      setLoading(true);
      setError(null);
      setAgentInstructions(null);
      setErrorAnalysis(null);

      try {
        const agentData = await createAgent({
          prompt: prompt || 'default prompt',
          agentRole: agentRole || 'default role',
          agentResponsibilities: agentResponsibilities || 'default responsibilities',
          reportingTo: reportingTo || undefined,
        });
        setAgentInstructions(agentData);

        toast({
          title: "Agent Created",
          description: "Your agent has been successfully created.",
        })

          let agents = JSON.parse(localStorage.getItem('agents') || '[]')
          agents.push({
            id: Date.now().toString(),
            name: agentRole || "Random Agent",
            status: 'active',
            taskProgress: 0,
            resourceUsage: 0,
            activityLevel: 0,
            dataLoad: 0,
            neuralLoad: 0
          })
          localStorage.setItem('agents', JSON.stringify(agents));

        // Redirect to the Live Tile Interactive dashboard upon successful agent creation
        router.push('/dashboard'); // Assuming you have a /dashboard route
      } catch (e: any) {
        setError(`Failed to create agent. Analyzing error...`);
        console.error("Agent creation error:", e);

        toast({
          variant: "destructive",
          title: "Error Creating Agent",
          description: "There was an error creating your agent.",
        })

        try {
          const analysis = await analyzePromptError({
            prompt: prompt,
            errorDetails: e.message || 'Unknown error',
          });
          setErrorAnalysis(analysis);
        } catch (analysisError: any) {
          console.error("Error analysis failed:", analysisError);
          setError(
            `Failed to analyze error: ${analysisError.message || 'Unknown error'}. Original error: ${e.message || 'Unknown error'}`
          );
        }
      } finally {
        setLoading(false);
      }
    };

    return (
      <Shell>
        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Agent Creation</CardTitle>
              <CardDescription>
                Translate your ideas into AI Agents.
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="prompt">Enter your prompt</Label>
                <Textarea
                  id="prompt"
                  placeholder="e.g., Create an agent that summarizes news articles."
                  value={prompt}
                  onChange={handlePromptChange}
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="agentRole">Enter the Agent Role</Label>
                <Textarea
                  id="agentRole"
                  placeholder="e.g., Security Agent"
                  value={agentRole}
                  onChange={handleAgentRoleChange}
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="agentResponsibilities">Enter the Agent Responsibilities</Label>
                <Textarea
                  id="agentResponsibilities"
                  placeholder="e.g., Handeling Random Access Checks"
                  value={agentResponsibilities}
                  onChange={handleAgentResponsibilitiesChange}
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="reportingTo">Reporting To (Optional)</Label>
                <Textarea
                  id="reportingTo"
                  placeholder="e.g., Network Operations Manager"
                  value={reportingTo}
                  onChange={handleReportingToChange}
                />
              </div>

              <Button onClick={handleCreateAgent} disabled={loading}>
                {loading ? 'Creating...' : 'Create Agent'}
              </Button>

              {error && (
                <Alert variant="destructive">
                  <Icons.close className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>
                    {error}
                    {errorAnalysis && (
                      <>
                        <br />
                        <strong>Analysis:</strong> {errorAnalysis.analysis}
                        <br />
                        <strong>Suggested Solutions:</strong>
                        <ul>
                          {errorAnalysis.suggestedSolutions.map((solution, index) => (
                            <li key={index}>{solution}</li>
                          ))}
                        </ul>
                      </>
                    )}
                  </AlertDescription>
                </Alert>
              )}

              {agentInstructions && (
                <div className="mt-4">
                  <h3>Agent Creation Successful!</h3>
                  <p><strong>Agent Instructions:</strong> {agentInstructions.agentInstructions}</p>
                  <p><strong>Agent Type:</strong> {agentInstructions.agentType}</p>
                  <p><strong>Required Skills:</strong> {agentInstructions.requiredSkills.join(', ')}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </Shell>
    );
  } catch (error: any) {
    console.error('Error in AgentCreationInterface:', error);
    return (
      <Shell>
        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Error</CardTitle>
              <CardDescription>An error occurred while rendering the agent creation interface.</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Please try again later.</p>
              <p>Error details: {error.message}</p>
            </CardContent>
          </Card>
        </div>
      </Shell>
    );
  }
};

export default AgentCreationInterface;
